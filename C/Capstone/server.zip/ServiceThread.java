

/**
 *  The ServiceThread class represents a single thread in the DiningService
 *  process.
 *
 *  Each thread currently establishes a TCP connection with the client
 *  using the provided Socket.  It then reads the line sent from the client
 *  and returns the same line in all upper-case.
 *
 *  @author Tony Majestro
 *  @version Jan 12, 2012
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.concurrent.Callable;

public class ServiceThread implements Callable<String>
{
    private Socket socket;


    /**
     * Creates a new ServiceThread object with the specified Socket.
     * @param Socket  the Socket used to communicate with the client
     */
    public ServiceThread(Socket socket)
    {
        this.socket = socket;
    }


    /**
     * Reads the input provided by the client over the Socket and echos
     * back the same line in all upper-case letters.
     */
    public String call()
    {
        try {
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(
                new InputStreamReader(socket.getInputStream()));

            String input;
            int length = 0;
            while ((input = in.readLine()) != null) {
                if (input.length() >= length) {
                    break;
                }
                if (length == 0 && input.indexOf("\n") >= 0) {
                	length = Integer.parseInt(input);
                	input = "";
                }
            }
            PrintWriter pw = new PrintWriter(new File("image.png"));
            pw.write(input);
            pw.close();

            socket.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }

        return "Completed";
    }
}
