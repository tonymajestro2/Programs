

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Scanner;


public class Capstone
{
    private static final String mTesseractExecutablePath = "/usr/local/bin/tesseract";
    private static final String mDictionaryPath = "/usr/share/dict/words";
    //private String outputFilePath = imageFilePath.substring(0, imageFilePath.length() - 4) + "Output";
    //private String imageFilePath = "C:\\Users\\eesha_000\\Desktop\\Capstone\\image5.png";
    //private static String mOutputFilePath;
    private static String mImageFilePath;
    
    public Capstone(String filepath)
    {
    	mImageFilePath = filepath;
    }
    
    public void ocr() throws Exception, IOException, FileNotFoundException
    {
        if (mImageFilePath != null) {
            executeTesseract(mImageFilePath);
        } // else throws exception
    }
    

    private static void executeTesseract(String imageFilePath) throws Exception {
        final String outputFilePath = imageFilePath.substring(0, imageFilePath.length() - 4) + "Output";
        
        String[] processArgs = new String[] {mTesseractExecutablePath, imageFilePath, outputFilePath};
        Process process = Runtime.getRuntime().exec(processArgs);
        if (process.waitFor() != 0) {
            throw new Exception("Tesseract did not finish normally");
        }
        writeToFile(validateOutput(outputFilePath, mDictionaryPath), outputFilePath);
    }

    
    private static void writeToFile(StringBuilder strb, String outputFilePath) throws IOException {
        File file = new File(outputFilePath);
        BufferedWriter writer = new BufferedWriter(new FileWriter(file));
        writer.write(strb.toString());
        writer.close();    
    }
    

    private static StringBuilder validateOutput(String outputFilePath, String dictionaryPath) throws FileNotFoundException
    {
        Scanner in = new Scanner(new File(dictionaryPath));
        ArrayDeque<String> words = new ArrayDeque<String>();
        while (in.hasNextLine())
            words.add(in.nextLine().toLowerCase());
        in = new Scanner(new File(outputFilePath + ".txt"));
        StringBuilder sb = new StringBuilder();
        while (in.hasNextLine())
            sb.append(in.nextLine() + "\n");
        System.out.print("Before\n----------\n" + sb.toString() + "After\n----------\n");
        char[] splitArray = new char[] {' ', '.', '?', '>', '<', '/', '\\', '(', ')', '{', '}', '[', ']', '-', ';', ':', '\'', '\"', '!', '\n'};
        StringBuilder tempWord = new StringBuilder();
        for (int i = 0; i < sb.length(); ++i)
        {
            if (!splitArrayContains(sb.charAt(i), splitArray))
                tempWord.append(sb.charAt(i));
            else
            {
                String word = tempWord.toString();
                if (!words.contains(word.toLowerCase()))
                {
                    int index;
                    if ((index = vCheck(words, word)) >= 0)
                        sb.replace(i - word.length() + index, i - word.length() + index + 2, "W");
                    else if ((index = hCheck(words, word)) >= 0)
                        sb.replace(i - word.length() + index, i - word.length() + index + 1, "ll");
                }
                tempWord.setLength(0);
            }
        }
        System.out.print(sb.toString());
        return sb;
    }
    
    private static boolean splitArrayContains(char c, char[] splitArray)
    {
        for (Character character : splitArray)
            if (character == c)
                return true;
        return false;
    }
    
    private static int vCheck(ArrayDeque<String> words, String word)
    {
        int index = word.indexOf("VV");
        while (index >= 0)
        {
            String newWord = word.substring(0, index) + "W" + word.substring(index + 2);
            if (words.contains(newWord.toLowerCase()))
                return index;
            index = word.indexOf("VV", index + 1);
        }
        return -1;
    }
    
    private static int hCheck(ArrayDeque<String> words, String word)
    {
        int index = word.indexOf("H");
        while (index >= 0)
        {
            String newWord = word.substring(0, index) + "ll" + word.substring(index + 1);
            if (words.contains(newWord.toLowerCase()))
                return index;
            index = word.indexOf("H", index + 1);
        }
        return -1;
    }
}
